<!-- mijn css -->
<link rel="stylesheet" href="style/style.css">
<!-- google font link -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<!-- fonts -->
<link href="https://fonts.googleapis.com/css2?family=Freckle+Face&family=Princess+Sofia&display=swap" rel="stylesheet">
<!-- tailwind cdn -->
<script src="https://unpkg.com/@tailwindcss/browser@4" type="style"></script>
